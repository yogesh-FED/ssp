const API_URLS = {
    development: 'http://localhost:5000/api',
    staging: 'https://staging-api.example.com/api',
    production: 'https://api.example.com/api',
    familyDetails: "workingJson/familyDetails.json"
  };
  export default API_URLS;