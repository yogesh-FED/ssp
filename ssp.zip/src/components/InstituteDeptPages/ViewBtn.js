import React from "react";

export default () => {
  return (
    <button onClick={() => window.alert("Software Launched")}>View</button>
  )
}