import React from 'react'

const FeeDetails = () => {
  return (
    <div>FeeDetails</div>
  )
}

export default FeeDetails