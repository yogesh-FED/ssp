import React from 'react'

const FilterComp = () => {
  return (
    <div>FilterComp</div>
  )
}

export default FilterComp
